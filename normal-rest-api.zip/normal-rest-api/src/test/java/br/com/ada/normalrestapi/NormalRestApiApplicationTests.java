package br.com.ada.normalrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NormalRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
