package br.com.ada.normalrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NormalRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NormalRestApiApplication.class, args);
	}

}
