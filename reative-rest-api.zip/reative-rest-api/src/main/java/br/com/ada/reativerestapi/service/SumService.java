package br.com.ada.reativerestapi.service;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.math.BigInteger;

@Service
public class SumService {

    public Mono<BigInteger> sum() {
        return Mono.just(this.sum(1000));
    }

    private BigInteger sum(Integer num) {
        BigInteger sum = BigInteger.ONE;
        long t1 = System.nanoTime();
        for (int i = 2; i <= 10000 ; i++) {
            sum.multiply(BigInteger.valueOf(i));
        }
        return sum;
    }

}
