package br.com.ada.reativerestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReativeRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReativeRestApiApplication.class, args);
	}

}
