package br.com.ada.reativerestapi.controller;

import br.com.ada.reativerestapi.service.SumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.math.BigInteger;

@RestController
@RequestMapping("/sum")
public class ReactiveController {

    @Autowired
    private SumService sumService;

    @GetMapping
    public Mono<BigInteger> sum() {
        return this.sumService.sum();
    }

}
